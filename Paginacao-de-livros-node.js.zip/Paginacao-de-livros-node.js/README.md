<h1>Exercício Paginacao de Livros</h1>
=======
<p>Para ser acessado pelo(a) usuário(a) pela primeira vez</p>

<br>
<br>

<p>Instale o Mongo DB</p>
<p><a href="https://www.mongodb.com/try/download/community">Link Site</a>

<br>
<br>

<p>Adicione os dados do CSV arquivo</p>
<p><img src="./images/image1.png"/><p>

<p style="color:red; font:bolder">Certifique-se de estar rodando na mesma porta para o arquivo db.js (Ex: localhost:27017)</p>

<br>
<br>

<p>Instale o Node, conforme código para a plataforma escolhida</p>

<p><a href="https://nodejs.org/en/download/package-manager">Link Download</a>

<p><img src="./images/image2.png"/><p>

<p>É importante clicar na segunda aba da figura acima para entrar no link que direciona para a instalação do Node</p>

<br>
<br>


<p>Instale os pacotes requeridos</p>

<p>Abra o terminal na mesma pasta do projeto e execute o comando:</p>

<b><p>npm install</p></b>

<br>
<br>

<p>Basta executar o projeto com o terminal aberto na mesma pasta do projeto execute o comando:</p>

<b><p>node .\server.js</p></b>
<br>
<br>

<p>Poderá ser acessado no navegador na porta executando no momento como 3000 exemplo (localhost:3000)</p>
<b><p>Server running on port 3000</p></b>

<br>
<br>
<b><p>FIM</p></b>


